<?php

include_once("../class/admin_function.php");

session_start();

foreach($_POST as $key => $value)
{
	$_POST[$key]= str_replace("'","\'",$value);	
}

$admin = new admin();

extract($_POST);


if(isset($_POST["id"]))
{

    if($admin->updateContentData("services",$title,$description,$sdescription,$id)==1)
    {
        $_SESSION['smsgbox']="Services successfully Updated.";
    }
    else
    {
        $_SESSION['emsgbox']="Error Updating Services.";
    }
    
    header("Location:services.php?id=".$id);

}
else
{
    if($admin->addContentData("services",$title,$description,$sdescription)==1)
    {
        $_SESSION['smsgbox']="Services successfully Added.";
    }
    else
    {
        $_SESSION['emsgbox']="Error adding Services.";
    }

    header("Location:services.php");

}






?>