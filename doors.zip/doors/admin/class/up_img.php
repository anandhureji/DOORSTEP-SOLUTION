<?php

class imgUP
{
	
	function uploadImage($source,$dest,$main_image_size=500,$thumb_image=false,$thumb_image_size=100,$type='o')
	{
	
		$image_names[]=null;
		$img_string="";
		$img_one="";
		$up_file=$source;
		function file_extension($filename)
		{
			$path_info = pathinfo($filename);
			return strtolower($path_info['extension']);
		}
		$img_cnt=0;
		$total = count($up_file['name']);
		for($i=0; $i<$total; $i++) 
		{ 
		  $image=$up_file['name'][$i];
		  if($image!="")
		  {
			  $ext=file_extension($image);
			  $image=str_replace('.','',md5($image.time()))."_".$i.".".$ext;
			  
			  $tmpFilePath = $up_file['tmp_name'][$i];
			  if ($tmpFilePath != "")
			  {
				$main_path=$dest;
				$newFilePath = $main_path."/" .$image;
				$newFilePathT = $main_path."/thumb/" .$image;
		
				//$admin->addImage($last_id,$imgdescE[$i],$imgdescA[$i],$image,$admin_id);		
				if(move_uploaded_file($tmpFilePath, $newFilePath))
				{
					$image_names[$img_cnt]=$image;
					$img_string.=$image."#";
					$img_one=$image;
					
					$img_cnt++;
					//////////////////thumb image//////////////////////////////////
					$imag = new SimpleImage();
					$imag->load($newFilePath);
					$org_width=$main_image_size;
					$org_height=$main_image_size;
					$actual_width = $imag->getWidth($newFilePath);
					$actual_height = $imag->getHeight($newFilePath);
					 if($actual_width >$org_width){
						 $imag->resizeToWidth($org_width);
					 }else if($actual_height >$org_height){
						 $imag->resizeToHeight($org_height);
					 }
					$imag->save($newFilePath);	
					
					if($thumb_image==true)
					{
						//thumb img
						$imag->load($newFilePath);
						$org_width=$thumb_image_size;
						$org_height=$thumb_image_size;
						$actual_width = $imag->getWidth($newFilePath);
						$actual_height = $imag->getHeight($newFilePath);
						 if($actual_width >$org_width){
							 $imag->resizeToWidth($org_width);
						 }else if($actual_height >$org_height){
							 $imag->resizeToHeight($org_height);
						 }
						$imag->save($newFilePathT);	
					}
				}		
					
			  } 
		  }
		}
		
		
		if($type=='s')
		{
			return $img_string;
		}
		else if($type=='o')
		{
			return $img_one;
		}
		else
		{
			return $image_names;
		}
		
		
	}
}

?>

<?php
 
class SimpleImage {
 
   var $image;
   var $image_type;
 
   function load($filename) {
 
      $image_info = getimagesize($filename);
      $this->image_type = $image_info[2];
      if( $this->image_type == IMAGETYPE_JPEG ) {
 
         $this->image = imagecreatefromjpeg($filename);
      } elseif( $this->image_type == IMAGETYPE_GIF ) {
 
         $this->image = imagecreatefromgif($filename);
      } elseif( $this->image_type == IMAGETYPE_PNG ) {
 
         $this->image = imagecreatefrompng($filename);
      }
   }
   function save($filename, $image_type=IMAGETYPE_JPEG, $compression=75, $permissions=null) {
 
      if( $image_type == IMAGETYPE_JPEG ) {
         imagejpeg($this->image,$filename,$compression);
      } elseif( $image_type == IMAGETYPE_GIF ) {
 
         imagegif($this->image,$filename);
      } elseif( $image_type == IMAGETYPE_PNG ) {
 
         imagepng($this->image,$filename);
      }
      if( $permissions != null) {
 
         chmod($filename,$permissions);
      }
   }
   function output($image_type=IMAGETYPE_JPEG) {
 
      if( $image_type == IMAGETYPE_JPEG ) {
         imagejpeg($this->image);
      } elseif( $image_type == IMAGETYPE_GIF ) {
 
         imagegif($this->image);
      } elseif( $image_type == IMAGETYPE_PNG ) {
 
         imagepng($this->image);
      }
   }
   function getWidth() {
 
      return imagesx($this->image);
   }
   function getHeight() {
 
      return imagesy($this->image);
   }
   function resizeToHeight($height) {
 
      $ratio = $height / $this->getHeight();
      $width = $this->getWidth() * $ratio;
      $this->resize($width,$height);
   }
 
   function resizeToWidth($width) {
      $ratio = $width / $this->getWidth();
      $height = $this->getheight() * $ratio;
      $this->resize($width,$height);
   }
 
   function scale($scale) {
      $width = $this->getWidth() * $scale/100;
      $height = $this->getheight() * $scale/100;
      $this->resize($width,$height);
   }
 
   function resize($width,$height) {
      $new_image = imagecreatetruecolor($width, $height);
      imagecopyresampled($new_image, $this->image, 0, 0, 0, 0, $width, $height, $this->getWidth(), $this->getHeight());
      $this->image = $new_image;
   }      
 
}
?>