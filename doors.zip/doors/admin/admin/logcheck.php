<?php
session_start();
ob_start();
include_once("../class/admin_function.php");








$admin=new admin();
$uname=$_POST['username'];
$_SESSION['uname']=$uname;
$pwd=md5($_POST['password']);


$res=$admin->login($uname,$pwd);


if(mysqli_num_rows($res)>0)
{
	$rw=mysqli_fetch_array($res);
	$_SESSION['user_id']=$rw['user_id'];
	$_SESSION['role_id']=$rw['role_id'];
	$_SESSION['uname']=$rw['user_username'];
	//echo $_SESSION['id'];
	if($rw['role_id']=='1'){
	header("location:home.php");
	}
}
else
{
	$msg="Invalid Login !!";
	$_SESSION['msg']=$msg;
	header("location:index.php");
}




?>