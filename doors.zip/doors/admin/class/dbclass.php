<?php
class  dbclass
{
    private $con;
    public function __construct()
	{
		$this->con=mysqli_connect("localhost","root","");
		//$this->con=mysqli_connect("localhost","freelan2_sat2","P(u)qyv#1aS}");
		if(!mysqli_error($this->con))
		{
			mysqli_select_db($this->con,"db_doors");
			//mysqli_select_db($this->con,"freelan2_sathees2");
			return true;
		}
		else
		{
			die("could not connect to the database");
		}
	}
	
	
	public function execute($query)
	{
		if(!mysqli_error($this->con))
		{
			mysqli_query($this->con,"SET NAMES utf8;");
			mysqli_query($this->con,"SET CHARACTER_SET utf8;");
			/*///////////////////////////////////////////////*/
			$res=mysqli_query($this->con,$query);
			return $res;
		}
	}
	
	
	
}
?>