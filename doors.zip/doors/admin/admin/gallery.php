<?php include_once("include/header.php"); 
?>   
        <div id="page-wrapper" >
            <div id="page-inner">
                
                <div class="row">
                    <div class="col-md-12">
                            <div class="panel-heading">
                              <h2> Gallery Image </h2>
                              
                              
    <div id="imgC">
    
    <div class="form-group has-feedback">
    
    
    
    <form method="post" enctype="multipart/form-data" action="gallery_action.php">

            <label class="control-label">Enter Group Title</label>
            <input class="form-control" type="text" placeholder="Title" name="title" id="title" required/>       

            <label class="control-label">Select Image</label>
               <input type="file" name="upload[]" accept="image/jpeg" multiple required/>

            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
            <span id="inputStatus" class="sr-only">(success)</span>
            

                                                  
            <div style="clear:both;margin-bottom:10px;"></div>
            
             
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Upload Images</button>
             </div>
      </form>       
            
     </div>
     
     
        <div class='form-group has-feedback'> 
            <?php 
                $img_data=$admin->gatImageList();
                $flag="";
                while($img_rw=mysqli_fetch_assoc($img_data))
                {
                    if ($img_rw['title']!=$flag){ $flag = $img_rw['title']; echo "<div style='width100%;clear:both;'>".$img_rw['title']."</div>"; }
                       
                    
                    ?>
                    <div style="float:left;margin-right:10px;right:0;">
                        <a class="btn btn-danger btn-xs" style="position: absolute;margin-left: 79px;" onclick="return confirmDelete();"
                            href="delete_img.php?img_id=<?php echo  $img_rw['image_id']; ?>&img=<?php echo  $img_rw['image']; ?>">
                            <i class="fa fa-trash" aria-hidden="true"></i>
                        </a>
                        <img height="100" width="100"  src="../../upload/gallery/thumb/<?php  echo $img_rw['image'];  ?>" />
                    </div>
        <?php   

                }
            ?>
        </div>
    </div>
     <div style="clear:both;margin:20px;"></div><br />
                              
                              
                              
                            </div>  
                        <h5></h5>   
                    </div>
                </div><!-- /. ROW  -->
                

            
            </div><!-- /. PAGE INNER  -->
        </div><!-- /. PAGE WRAPPER  -->
       
    </div><!-- /. WRAPPER  -->

    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->

    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/validation.js"></script>
    

    
   
</body>
</html>
﻿