<?php
include_once("dbclass.php");
include_once("pagination_func.php");
//error_reporting(0);
//session_start();
ob_start();





//$rootpath= url()."/";
$rootpath= "";

class pub
{


	
	
	function getContent($id,$type)
	{
		$db= new dbclass();

		$query="SELECT  `content_head` as head,`content_description` as des,`content_image` as img FROM `tbl_content` where content_id='$id'";
				
		$res=$db->execute($query);
		
		$rw=mysqli_fetch_array($res);

		$content_re=str_replace("../../upload/gal/",$rootpath."upload/gal/",$rw[$type]);
		
		return $content_re;	
	}
	
	
		
	
	function gatImageList()
	{
		$db= new dbclass();
		$query="select * from tbl_gallery_image order by image_id desc";
		$res=$db->execute($query);
		return $res;	
	}
	


	
	
	function gatOneContentData($about,$id)
	{
		$db= new dbclass();

		$query="select * from tbl_".$about." WHERE ".$about."_id='$id'";
		
		$res=$db->execute($query);
		return $res;	
	}


	

	function setSettings($name,$value)
	{
		$db= new dbclass();
		$chkres=$db->execute("select * from tbl_settings where settings_name='$name'");

		if(mysqli_num_rows($chkres)==0)
		{
			$query="INSERT INTO `tbl_settings` (`settings_name`, `settings_value`) VALUES ('$name', '$value')";
		}
		else
		{
			$query="UPDATE `tbl_settings` SET `settings_value`='$value' WHERE  `settings_name`='$name'";
		}
		$res=$db->execute($query);
		return $res;
	}
	
	function getSettings($name)
	{
		$db= new dbclass();
		$query="SELECT settings_value from tbl_settings where  `settings_name`='$name'";
		$res=$db->execute($query);

		if(mysqli_num_rows($res)!=0)
		{
			$rw=mysqli_fetch_assoc($res);
			return $rw["settings_value"];	
		}
		else
		{
			return "";
		}
	}

	


	function getUrlAbout($about,$id)
	{
		$db= new dbclass();
		$query="select * from tbl_".$about." where ".$about."_id='$id' ";
		$res=$db->execute($query);
		if( mysqli_num_rows($res)!=0 )
		{
			$rw=mysqli_fetch_array($res);
			return $rw[$about."_id"]."/". strtolower(str_replace(" ","-",$rw[$about."_head"]));
		}
		else
		{
			return "";
		}
			
	}

	function getWarrantyData($sno)
	{
		$db= new dbclass();
		$query="select * from tbl_dups where dupsdata='$sno'";
		$res=$db->execute($query);	
		return $res;	
	}

	function updateWarrantyNew($dupsdata,$data1,$data2)
	{
		$db= new dbclass();

		$query="UPDATE `tbl_dups` SET `dopur`=curdate(),`data1`='$data1',`data2`='$data2' WHERE `dupsdata`='$dupsdata'";
		
		$res=$db->execute($query);
		return $res;
	}



	//start


	function sugnUp($user_name,  $user_email,  $user_password,  $phno, $address,  $guide)
	{
		$db= new dbclass();

		$query="INSERT INTO `tbl_users` ( `user_name`, `user_email`, `user_password`, `phno`,`address`, `guide`, `user_status`, `role_id`) 
				VALUES ('$user_name', '$user_email', '".md5($user_password)."', '$phno','$address' , '$guide', 'active', 0);
";
		
		$res=$db->execute($query);
		return $res;
	}

	function login($email,$pwd) //check login
	{
		$db= new dbclass();
		$query="select * from tbl_users where user_email='$email' and user_password='$pwd' and user_status='active' and role_id=0";
		$res=$db->execute($query);

		return $res;
	}


	function userData($id)
	{
		$db= new dbclass();
		$query="select * from tbl_users where user_id='$id'";
		$res=$db->execute($query);

		return $res;
	}

	
	function updateProfile($name, $phone, $address,  $guide,$ID)
	{
		$db= new dbclass();

		$query="UPDATE `tbl_users` SET   `user_name`='$name', `phno`='$phone',`address`='$address', `guide`='$guide' WHERE user_id='$ID' ";

		$res=$db->execute($query);
		return $res;
	}
	
	

}








?>