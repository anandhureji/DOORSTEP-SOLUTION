<?php


	session_start();
	include_once("../class/admin_function.php");
	include_once('../class/up_img.php');
	
	
	extract($_POST);
	$admin= new admin(); 
	
	$im=new imgUP();
	$img_names=$im->uploadImage($_FILES['upload'],"../../upload/gallery/",1000,true,400,'a');
	
	//for many ---is good

	$title=str_replace("'","\'",$title);

	for($i=0;$i<count($img_names);$i++)
	{
		$admin->addImage($img_names[$i],$title);
	}

	$_SESSION['smsgbox']="Successfully added.";


	
	header("Location:gallery.php");



?>