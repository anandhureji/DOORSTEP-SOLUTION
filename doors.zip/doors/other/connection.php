<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "doorstepdb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}




$emailid = $_POST["emailid"];
$systeminfo = $_POST["systeminfo"];
$spec = $_POST["spec"];
$usrname = $_POST["usrname"];
$address = $_POST["address"];
$pincode = $_POST["pincode"];
$country = $_POST["country"];
$phno = $_POST["phno"];
$message = $_POST["message"];

$sql = "insert into comp_register (e_mail,system_info,specification,usr_name,address,pin_code,Country,phno,message) values ('$emailid','$systeminfo','$spec','$usrname','$address','$pincode','$country','$phno','$message');";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>