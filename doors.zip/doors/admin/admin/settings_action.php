<?php

include_once("../class/admin_function.php");

session_start();

foreach($_POST as $key => $value)
{
	$_POST[$key]= str_replace("'","\'",$value);	
}

$admin = new admin();


foreach($_POST as $key => $value)
{
    $admin->setSettings($key,$value);
}


$_SESSION['smsgbox']="Settings Changed";


header("Location:settings.php");








?>