<?php include_once("include/header.php"); ?>
 

        <div id="page-wrapper" >
            <div id="page-inner">
                
                <div class="row">
                    <div class="col-md-12">
                            <div class="panel-heading">
                              <h2> Settings </h2>
                            </div> 
                       
                    </div>
                    
                </div>
                

                
                <div class="row">
                    <div class="col-md-12"><!-- Form Elements -->
                        <div class="panel panel-default">
                            

                            
                            <div class="col-lg-6">
                                <div class="panel-body">
                                  
                                        <h3></h3>
                                        
                                        <form role="form"  action="settings_action.php" enctype="multipart/form-data" method="post" name="form1">

                                            <div class="form-group has-feedback">
                                                <label class="control-label">Name   <span style="color:#990000">*</span></label>

                                                <input class="form-control" 
                                                        name="name" 
                                                        value="<?php echo $admin->getSettings("name"); ?>" 
                                                        placeholder="Name" type="text" aria-describedby="inputStatus">

                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>

                                            <div class="form-group has-feedback">
                                                <label class="control-label">Title   <span style="color:#990000">*</span></label>

                                                <input class="form-control" 
                                                        name="title" 
                                                        value="<?php echo $admin->getSettings("title"); ?>" 
                                                        placeholder="Title" type="text" aria-describedby="inputStatus">

                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>

                                            <div class="form-group has-feedback">
                                                <label class="control-label">Address Line1   <span style="color:#990000">*</span></label>

                                                <input class="form-control" 
                                                        name="addressL1" 
                                                        value="<?php echo $admin->getSettings("addressL1"); ?>" 
                                                        placeholder="Address Line1" type="text" aria-describedby="inputStatus">

                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>

                                            <div class="form-group has-feedback">
                                                <label class="control-label">Address Line2   <span style="color:#990000">*</span></label>

                                                <input class="form-control" 
                                                        name="addressL2" 
                                                        value="<?php echo $admin->getSettings("addressL2"); ?>" 
                                                        placeholder="Address Line2" type="text" aria-describedby="inputStatus">

                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>

                                            <div class="form-group has-feedback">
                                                <label class="control-label">Address Line3   <span style="color:#990000">*</span></label>

                                                <input class="form-control" 
                                                        name="addressL3" 
                                                        value="<?php echo $admin->getSettings("addressL3"); ?>" 
                                                        placeholder="Address Line3" type="text" aria-describedby="inputStatus">

                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>


                                            <div class="form-group has-feedback">
                                                <label class="control-label">Email   <span style="color:#990000">*</span></label>

                                                <input class="form-control" 
                                                        name="email" 
                                                        value="<?php echo $admin->getSettings("email"); ?>" 
                                                        placeholder="Email" type="text" aria-describedby="inputStatus">

                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>

                                            <div class="form-group has-feedback">
                                                <label class="control-label">Url   <span style="color:#990000">*</span></label>

                                                <input class="form-control" 
                                                        name="url" 
                                                        value="<?php echo $admin->getSettings("url"); ?>" 
                                                        placeholder="url" type="text" aria-describedby="inputStatus">

                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>

                                            <div class="form-group has-feedback">
                                                <label class="control-label">Phone   <span style="color:#990000">*</span></label>

                                                <input class="form-control" 
                                                        name="phone" 
                                                        value="<?php echo $admin->getSettings("phone"); ?>" 
                                                        placeholder="Phone" type="text" aria-describedby="inputStatus">

                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>

                                            <div class="form-group has-feedback">
                                                <label class="control-label">Mobile   <span style="color:#990000">*</span></label>

                                                <input class="form-control" 
                                                        name="mobile" 
                                                        value="<?php echo $admin->getSettings("mobile"); ?>" 
                                                        placeholder="mobile" type="text" aria-describedby="inputStatus">

                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>
                                            
                                            <hr>
                                            <div class="form-group has-feedback">
                                                <label class="control-label">Facebook   <span style="color:#990000">*</span></label>

                                                <input class="form-control" 
                                                        name="facebook" 
                                                        value="<?php echo $admin->getSettings("facebook"); ?>" 
                                                        placeholder="Facebook" type="text" aria-describedby="inputStatus">

                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>

                                            <div class="form-group has-feedback">
                                                <label class="control-label">Google+   <span style="color:#990000">*</span></label>

                                                <input class="form-control" 
                                                        name="googlep" 
                                                        value="<?php echo $admin->getSettings("googlep"); ?>" 
                                                        placeholder="Google+" type="text" aria-describedby="inputStatus">

                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>

                                            <div class="form-group has-feedback">
                                                <label class="control-label">You Tube   <span style="color:#990000">*</span></label>

                                                <input class="form-control" 
                                                        name="youtube" 
                                                        value="<?php echo $admin->getSettings("youtube"); ?>" 
                                                        placeholder="You Tube" type="text" aria-describedby="inputStatus">

                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>

                                            <br>
                                            <div class="form-group has-feedback">
                                                <label class="control-label">Facebook iframe url   <span style="color:#990000">*</span></label>

                                                <input class="form-control" 
                                                        name="facebookiframe" 
                                                        value="<?php echo $admin->getSettings("facebookiframe"); ?>" 
                                                        placeholder="Facebook iframe url" type="text" aria-describedby="inputStatus">

                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>

                                            <div class="form-group has-feedback">
                                                <label class="control-label">Map iframe url   <span style="color:#990000">*</span></label>

                                                <input class="form-control" 
                                                        name="mapiframe" 
                                                        value="<?php echo $admin->getSettings("mapiframe"); ?>" 
                                                        placeholder="Map iframe url" type="text" aria-describedby="inputStatus">

                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>

                                            <div class="form-group has-feedback">
                                                <label class="control-label">No Reply Email id   <span style="color:#990000">*</span></label>

                                                <input class="form-control" 
                                                        name="noreplyemail" 
                                                        value="<?php echo $admin->getSettings("noreplyemail"); ?>" 
                                                        placeholder="No Reply Email id" type="text" aria-describedby="inputStatus">

                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>




                                            
                                             <br />
                                            <button type="submit" class="btn btn-success">Change Settings</button>
                                           
                                        </form>
                                     
                                    <br/>
                                    <h3></h3>
                                </div>                           
                            </div>

                            <div class="col-lg-6">
                                <h3></h3>
                                <p></p>
                            </div>
                       
                        </div>
                    </div>
                </div>
                
                <!-- /. ROW  -->
                <div class="row">
                    <div class="col-md-12">
                        <h3></h3>
                         <p>
                       
                        </p>
                    </div>
                </div><!-- /. ROW  -->
            
            </div><!-- /. PAGE INNER  -->
        </div><!-- /. PAGE WRAPPER  -->
       
    </div><!-- /. WRAPPER  -->

    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-2.1.3.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.0/jquery.validate.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.0/additional-methods.min.js"></script>
    <script src="assets/js/validation.js"></script>
    
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
