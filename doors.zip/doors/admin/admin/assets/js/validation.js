

$(function() {

	   $("input,textarea").blur(function(){

		  if( $(this).val().length == 0 || $.trim( $(this).val() ) == '') {
 			$(this).closest('.form-group').addClass('has-error').find(".glyphicon").addClass('glyphicon-warning-sign');
		  }
    });
    $("select").blur(function(){
		  if ($(this).children(":selected").val() === "" ) {
 			  $(this).closest('.form-group').addClass('has-error');
		}
    });
    $( "input,textarea" ).focus(function() {
      if ($(this).children(":selected").val() === "" ) {
      $(this).closest('.form-group').removeClass('has-error').removeClass('has-success');      
      $(this).closest('.form-group').find(".glyphicon").removeClass('glyphicon-warning-sign').removeClass('glyphicon-ok');
      }
    });

	$.validator.setDefaults({
    highlight: function(element) {
        $(element).closest('.form-group').addClass('has-error').find(".glyphicon").removeClass('glyphicon-ok').addClass('glyphicon-warning-sign');
    },
    unhighlight: function(element) {
        $(element).closest('.form-group').removeClass('has-error').addClass('has-success').find(".glyphicon").removeClass('glyphicon-warning-sign').addClass('glyphicon-ok');
    },
    errorElement: 'span',
    errorClass: 'help-block',
    errorPlacement: function(error, element) {
        if(element.parent('.input-group').length) {
            error.insertAfter(element.parent());
        } else {
            error.insertAfter(element);
        }
        
    },
    

	});
  
  $.validator.addMethod('greaterThan', function (value, element, param) {
      
      if( $("#mrp").val().length != '') {
        return this.optional(element) || parseInt(value) <= parseInt($(param).val());
      }
        
    });


  $("#add-book").validate({
    
      ignore: [],
      rules: {
      
      bookName: {
        required: true,
        nowhitespace: true,
        lettersonly: true
      },
      category: {
        required: true
      },
      authorName: {
      	required: true
      	
      },
      publisherName: {
      	required: true,
        nowhitespace: true,
        lettersonly: true
      },
      type: {
      	required: true,
      	lettersonly: true
      },
      summary: {
      	required: true
      },
      description: {
      	required: true
      },
      contents: {
      	required: true
      },
      mrp:{
      	required: true,
        min:1
        
      },
      offer_price: {
      	required: true,
        min: 1,
        greaterThan: "#mrp"
      },
      shipping_class: {
      	required: true
      },
      main_image: {
      	required: true,
      	accept: "image/*"
      },
      gallery_image_1: {
      	require_from_group: [1, ".gallery_img_group"],
      	accept: "image/*"
      },
      gallery_image_2: {
        require_from_group: [1, ".gallery_img_group"],
        accept: "image/*"
      },
      gallery_image_3: {
        require_from_group: [1, ".gallery_img_group"],
        accept: "image/*"
      },
      stock_quantity: {
      	required: true,
        min:1
      }
      
    },
    messages: {
      
      category: {
        required: 'Please select from the dropdown list.',
      },
      shipping_class: {
        required: 'Please select from the dropdown list.',
      },
      main_image: {
      	required: 'Please upload an image',
      	accept:jQuery.validator.format("Invalid extension. Use either GIF, JPG or PNG.") 
      },
      mrp: {
        min:jQuery.validator.format("Please enter a valid amount.")

      },
      offer_price: {
        greaterThan: 'Must be less than or equal to MRP.',
        min: jQuery.validator.format("Please enter a valid amount.")
      },
      gallery_image_1: {
      	require_from_group: 'Please upload at least one image',
      	accept: 'Invalid extension. Use either GIF, JPG or PNG.'
      },
      gallery_image_2: {
        require_from_group: 'Please upload at least one image',
        accept: 'Invalid extension. Use either GIF, JPG or PNG.'
      },
      gallery_image_3: {
        require_from_group: 'Please upload at least one image',
        accept: 'Invalid extension. Use either GIF, JPG or PNG.'
      },
      stock_quantity: {
        min: jQuery.validator.format("Please enter a valid amount.")
      }
      
    },
    errorPlacement : function(error, element) {
    if($(element).prop("id") === "gallery_imgInp1" || $(element).prop("id") === "gallery_imgInp2" || $(element).prop("id") === "gallery_imgInp3" ) {
        $("#g_error").append(error);
    }
    else if($(element).prop("id") === "imgInp" ) {
        $("#main_error").append(error);
    }
    else {
        error.insertAfter(element); // default error placement.
    }
    },
    groups: {
            inputGroup: "gallery_image_1 gallery_image_2 gallery_image_3",
    },
  });

  $("#add-cd").validate({
    
      ignore: [],
      rules: {
       ignore: [],
      cdName: {
        required: true
      },
      category: {
        required: true
      },
      authorName: {
      	required: true
      	
      },
      publisherName: {
      	required: true
      },
      type: {
      	required: true,
      	lettersonly: true
      },
      summary: {
      	required: true
      },
      description: {
      	required: true
      },
      contents: {
      	required: true
      },
      mrp:{
        required: true,
        min:1
        
      },
      offer_price: {
        required: true,
        min: 1,
        greaterThan: "#mrp"
      },
      shipping_class: {
      	required: true
      },
      main_image: {
        required: true,
        accept: "image/*"
      },
      gallery_image_1: {
        require_from_group: [1, ".gallery_img_group"],
        accept: "image/*"
      },
      gallery_image_2: {
        require_from_group: [1, ".gallery_img_group"],
        accept: "image/*"
      },
      gallery_image_3: {
        require_from_group: [1, ".gallery_img_group"],
        accept: "image/*"
      },
      stock_quantity: {
        required: true,
        min:1
      }
      
    },
    messages: {
      category: {
        required: 'Please select from the dropdown list.',
      },
      shipping_class: {
        required: 'Please select from the dropdown list.',
      },
      main_image: {
        required: 'Please upload an image',
        accept: 'Invalid extension. Use either GIF, JPG or PNG.'
      },
      mrp: {
        min:jQuery.validator.format("Please enter a valid amount.")

      },
      offer_price: {
        greaterThan: 'Must be less than or equal to MRP.',
        min: jQuery.validator.format("Please enter a valid amount.")
      },
      gallery_image_1: {
        require_from_group: 'Please upload at least one image',
        accept: 'Invalid extension. Use either GIF, JPG or PNG.'
      },
      gallery_image_2: {
        require_from_group: 'Please upload at least one image',
        accept: 'Invalid extension. Use either GIF, JPG or PNG.'
      },
      gallery_image_3: {
        require_from_group: 'Please upload at least one image',
        accept: 'Invalid extension. Use either GIF, JPG or PNG.'
      },
      stock_quantity: {
        min: jQuery.validator.format("Please enter a valid amount.")
      }
      
    },
    errorPlacement : function(error, element) {
    if($(element).prop("id") === "gallery_imgInp1" || $(element).prop("id") === "gallery_imgInp2" || $(element).prop("id") === "gallery_imgInp3" ) {
        $("#g_error").append(error);
    }
    else if($(element).prop("id") === "imgInp" ) {
        $("#main_error").append(error);
    }
    else {
        error.insertAfter(element); // default error placement.
    }
    },
    groups: {
            inputGroup: "gallery_image_1 gallery_image_2 gallery_image_3",
            
        },
  });

  $("#add-instrument").validate({
    ignore: [],
    rules: {
       ignore: [],
      instrumentName: {
        required: true
      },
      category: {
        required: true
      },
      brand: {
      	required: true
      	
      },
      instrumentType: {
      	required: true,
      	lettersonly: true
      },
      summary: {
      	required: true
      },
      description: {
      	required: true
      },
      technicalSpecification: {
      	required: true
      },
      contents: {
      	required: true
      },
      mrp:{
        required: true,
        min:1
        
      },
      gallery_image_1: {
        require_from_group: [1, ".gallery_img_group"],
        accept: "image/*"
      },
      gallery_image_2: {
        require_from_group: [1, ".gallery_img_group"],
        accept: "image/*"
      },
      gallery_image_3: {
        require_from_group: [1, ".gallery_img_group"],
        accept: "image/*"
      },
      offer_price: {
        required: true,
        min: 1,
        greaterThan: "#mrp"
      },
      shipping_class: {
      	required: true
      },
      stock_quantity: {
      	required: true
      },
      main_image: {
      	required: true,
      	accept: "image/*"
      }
      
    },
    messages: {
      category: {
        required: 'Please select from the dropdown list.',
      },
      shipping_class: {
        required: 'Please select from the dropdown list.',
      },
      main_image: {
        required: 'Please upload an image',
        accept: 'Invalid extension. Use either GIF, JPG or PNG.'
      },
      mrp: {
        min:jQuery.validator.format("Please enter a valid amount.")

      },
      offer_price: {
        greaterThan: 'Must be less than or equal to MRP.',
        min: jQuery.validator.format("Please enter a valid amount.")
      },
      gallery_image_1: {
        require_from_group: 'Please upload at least one image',
        accept: 'Invalid extension. Use either GIF, JPG or PNG.'
      },
      gallery_image_2: {
        require_from_group: 'Please upload at least one image',
        accept: 'Invalid extension. Use either GIF, JPG or PNG.'
      },
      gallery_image_3: {
        require_from_group: 'Please upload at least one image',
        accept: 'Invalid extension. Use either GIF, JPG or PNG.'
      },
      stock_quantity: {
        min: jQuery.validator.format("Please enter a valid amount.")
      }
      
    },
    errorPlacement : function(error, element) {
        if($(element).prop("id") === "gallery_imgInp1" || $(element).prop("id") === "gallery_imgInp2" || $(element).prop("id") === "gallery_imgInp3" ) {
            $("#g_error").append(error);
        }
        else if($(element).prop("id") === "imgInp" ) {
        $("#main_error").append(error);
        }
        else {
            error.insertAfter(element); // default error placement.
        }
    },
    groups: {
            inputGroup: "gallery_image_1 gallery_image_2 gallery_image_3",
            
    }
  });

	$("#add-banners").validate({
    ignore: [],
    rules: {
      bannerName: {
        required: true
      },
      altText: {
      	required: true
      },
      bannerType: {
      	required: true
      },
      link: {
      	required:true,
      	url: true
      },
      main_image: {
        required: true,
        accept: "image/*"
      }, 
    },
    messages: {
      
      main_image: {
        required: 'Please upload an image',
        accept: 'Invalid extension. Use either GIF, JPG or PNG.'
      }
      },
    errorPlacement : function(error, element) {
        
        if($(element).prop("id") === "imgInp" ) {
        $("#main_error").append(error);
        }
        else {
            error.insertAfter(element); // default error placement.
        }
    }
    
  });

  	$("#add-categories").validate({
    rules: {
      
      brandNameE: {
        required: true
      },
      brandNameA: {
      	required: true
      }
	  
	  
	  
	  
	  
    }
    
  	});

  	$("#add-tax-class").validate({
    rules: {
      
      state: {
        required: true
      },
      tax_rate: {
      	required: true
      },
      additional_info: {
      	required: true
      }
    }
    
  	});
    

  
   
  var _URL = window.URL || window.webkitURL;

   

  $("#imgInp").change(function(){
        
      var s=this;
      var file = $('#imgInp').val();
      var exts = ['jpg', 'jpeg', 'gif', 'png'];
      if ( file ) {
        var get_ext = file.split('.');
       
        get_ext = get_ext.reverse();
        
        if ( $.inArray ( get_ext[0].toLowerCase(), exts ) > -1 ){
                
                file = this.files[0];
                img = new Image();
                img.src = _URL.createObjectURL(file);
       
                img.onload=function() {
                var height = this.height;
                var width = this.width;
                
                window.URL.revokeObjectURL( img.src );

              if (height >= 600 || width >= 400) {
                    readURL(s);
                    $('#imgInp-error').hide();
                    $('#main-size-error').hide(); 
                    $("#add_mani_image").hide();
                    $("#imgInp").closest('.form-group').removeClass('has-error').addClass('has-success');
                    
              }
              else {
                $("#imgInp").prop('value', '');
                $('#imgInp-error').hide();
                $('#main-size-error').html("");
                $('#main-size-error').html("please upload an image with 400 pixels wide and 600 pixels tall.");
                $('#main-size-error').show();
                $("#imgInp").closest('.form-group').removeClass('has-success');
                $("#imgInp").closest('.form-group').addClass('has-error');

              }
            };
          } 
        else {
                $("#imgInp").prop('value', '');
                $('#imgInp-error').hide();
                $('#main-size-error').html("");
                $('#main-size-error').html("Invalid extension. Use either GIF, JPG or PNG.");
                $('#main-size-error').show();
                $("#imgInp").closest('.form-group').removeClass('has-success');
                $("#imgInp").closest('.form-group').addClass('has-error');
        }
      }   
    });

    $("#gallery_imgInp1").change(function(){
        
      var s=this;
      var file = $('#gallery_imgInp1').val();
      var exts = ['jpg', 'jpeg', 'gif', 'png'];
      if ( file ) {
        var get_ext = file.split('.');
       
        get_ext = get_ext.reverse();
        
        if ( $.inArray ( get_ext[0].toLowerCase(), exts ) > -1 ){
                
                file = this.files[0];
                img = new Image();
                img.src = _URL.createObjectURL(file);
       
                img.onload=function() {
                var height = this.height;
                var width = this.width;
                
                window.URL.revokeObjectURL( img.src );
              if (height >= 600 || width >= 600) {
                    readURL1(s);
                    $('#inputGroup-error').hide();
                    $('#g-size-error').hide();   
                    $(".gallery_images").closest('.form-group').removeClass('has-error');
                    $(".gallery_images").closest('.form-group').addClass('has-success');
              }
              else {
                $("#gallery_imgInp1").prop('value', '');
                $('#inputGroup-error').hide();
                $('#g-size-error').html("");
                $('#g-size-error').html("Please upload an image with 600 pixels wide and 600 pixels tall.");
                $('#g-size-error').show();
                $(".gallery_images").closest('.form-group').removeClass('has-success');
                $(".gallery_images").closest('.form-group').addClass('has-error');

              }
            };
          } 
        else {
                $("#gallery_imgInp1").prop('value', '');
                $('#inputGroup-error').hide();
                $('#g-size-error').html("");
                $('#g-size-error').html("Invalid extension. Use either GIF, JPG or PNG.");
                $('#g-size-error').show();
                $(".gallery_images").closest('.form-group').removeClass('has-success');
                $(".gallery_images").closest('.form-group').addClass('has-error');
        }
      }   
    });
    
    $("#gallery_imgInp2").change(function(){
        
      var s=this;
      var file = $('#gallery_imgInp2').val();
      var exts = ['jpg', 'jpeg', 'gif', 'png'];
      if ( file ) {
        var get_ext = file.split('.');
       
        get_ext = get_ext.reverse();
        
        if ( $.inArray ( get_ext[0].toLowerCase(), exts ) > -1 ){
                
                file = this.files[0];
                img = new Image();
                img.src = _URL.createObjectURL(file);
       
                img.onload=function() {
                var height = this.height;
                var width = this.width;
                
                window.URL.revokeObjectURL( img.src );
              if (height >= 600 || width >= 600) {
                    readURL2(s);
                    $('#inputGroup-error').hide();
                    $('#g-size-error').hide();   
                    $(".gallery_images").closest('.form-group').removeClass('has-error');
                    $(".gallery_images").closest('.form-group').addClass('has-success');
              }
              else {
                $("#gallery_imgInp2").prop('value', '');
                $('#inputGroup-error').hide();
                $('#g-size-error').html("");
                $('#g-size-error').html("Please upload an image with 600 pixels wide and 600 pixels tall.");
                $('#g-size-error').show();
                $(".gallery_images").closest('.form-group').removeClass('has-success');
                $(".gallery_images").closest('.form-group').addClass('has-error');

              }
            };
          } 
        else {
                $("#gallery_imgInp2").prop('value', '');
                $('#inputGroup-error').hide();
                $('#g-size-error').html("");
                $('#g-size-error').html("Invalid extension. Use either GIF, JPG or PNG.");
                $('#g-size-error').show();
                $(".gallery_images").closest('.form-group').removeClass('has-success');
                $(".gallery_images").closest('.form-group').addClass('has-error');
        }
      }   
    });

    $("#gallery_imgInp3").change(function(){
        
      var s=this;
      var file = $('#gallery_imgInp3').val();
      var exts = ['jpg', 'jpeg', 'gif', 'png'];
      if ( file ) {
        var get_ext = file.split('.');
       
        get_ext = get_ext.reverse();
        
        if ( $.inArray ( get_ext[0].toLowerCase(), exts ) > -1 ){
                
                file = this.files[0];
                img = new Image();
                img.src = _URL.createObjectURL(file);
       
                img.onload=function() {
                var height = this.height;
                var width = this.width;
                
                window.URL.revokeObjectURL( img.src );
              if (height >= 600 || width >= 600) {
                    readURL3(s);
                    $('#inputGroup-error').hide();
                    $('#g-size-error').hide();   
                    $(".gallery_images").closest('.form-group').removeClass('has-error');
                    $(".gallery_images").closest('.form-group').addClass('has-success');
              }
              else {
                $("#gallery_imgInp3").prop('value', '');
                $('#inputGroup-error').hide();
                $('#g-size-error').html("");
                $('#g-size-error').html("Please upload an image with 600 pixels wide and 600 pixels tall.");
                $('#g-size-error').show();
                $(".gallery_images").closest('.form-group').removeClass('has-success');
                $(".gallery_images").closest('.form-group').addClass('has-error');

              }
            };
          } 
        else {
                $("#gallery_imgInp3").prop('value', '');
                $('#inputGroup-error').hide();
                $('#g-size-error').html("");
                $('#g-size-error').html("Invalid extension. Use either GIF, JPG or PNG.");
                $('#g-size-error').show();
                $(".gallery_images").closest('.form-group').removeClass('has-success');
                $(".gallery_images").closest('.form-group').addClass('has-error');
        }
      }   
    });
    
    $("#imgp").hover(function(){
     if ($(this).children("img").val() != "" ) {
        $(this).find("span:nth-child(2)").show();
        
      }
      },
      function(){  
      $(this).find("span:nth-child(2)").hide();
    });
    $(".gallery_image1").hover(function(){
      
      if ($(this).children("img").val() != "" ) {
        $(this).find("span:nth-child(2)").show();
        
      }
      },
      function(){  
      $(this).find("span:nth-child(2)").hide();
    });
    $(".gallery_image2").hover(function(){
      
      if ($(this).children("img").val() != "" ) {
        $(this).find("span:nth-child(2)").show();
        
      }
      },
      function(){  
      $(this).find("span:nth-child(2)").hide();
    });
    $(".gallery_image3").hover(function(){
      
      if ($(this).children("img").val() != "" ) {
        $(this).find("span:nth-child(2)").show();
        
      }
      },
      function(){  
      $(this).find("span:nth-child(2)").hide();
    });
    $("#remove_main_image").click(function(){
        
        $('#img_main').removeAttr('src');
        $("#remove_main_image").hide();
        $("#add_mani_image").show();
        $("#img_main").prop('value', '');
        $("#imgInp").prop('value', '');
        $("#imgInp").closest('.form-group').removeClass('has-success');
        $("#imgInp").closest('.form-group').addClass('has-error');  
        
    });
    $("#remove_gallery_image1").click(function(){
      
        $("#img_gallery1").removeAttr('src');
        $("#remove_gallery_image1").hide();
        $("#add_gallery_image1").show();
        $("#gallery_imgInp1").prop('value', '');
        $("#img_gallery1").prop('value', '');
        $(".gallery_image1").css("border", "1px dashed #c5d7b5");
        $(".gallery_image1").css("height", "100px");
        if ($('#img_gallery1').val() == '' && $('#img_gallery2').val() == '' && $('#img_gallery3').val() == '') {
          $(".gallery_images").closest('.form-group').removeClass('has-success');
          $(".gallery_images").closest('.form-group').addClass('has-error');
        }
             
    });
    $("#remove_gallery_image2").click(function(){
      
        $("#img_gallery2").removeAttr('src');
        $("#remove_gallery_image2").hide();
        $("#add_gallery_image2").show();
        $("#gallery_imgInp2").prop('value', '');
        $("#img_gallery2").prop('value', '');

        if ($('#img_gallery1').val() == '' && $('#img_gallery2').val() == '' && $('#img_gallery3').val() == '') {
          $(".gallery_images").closest('.form-group').removeClass('has-success').addClass('has-error');;
         
        }
 
    });
    $("#remove_gallery_image3").click(function(){
      
        $("#img_gallery3").removeAttr('src');
        $("#remove_gallery_image3").hide();
        $("#add_gallery_image3").show();
        $("#gallery_imgInp3").prop('value', '');
        $("#img_gallery3").prop('value', '');

        if ($('#img_gallery1').val() == '' && $('#img_gallery2').val() == '' && $('#img_gallery3').val() == '') {
          $(".gallery_images").closest('.form-group').removeClass('has-success');
          $(".gallery_images").closest('.form-group').addClass('has-error');
        }
 
    });


    
  });


function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                
              $('#img_main').attr('src', e.target.result);  
              $("#img_main").prop('value', 'yes');
                
            }
            reader.readAsDataURL(input.files[0]);
        }
}
function readURL1(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                
                $(".gallery_image1").css("border", "none");
                $(".gallery_image1").css("height", "auto");
                $("#add_gallery_image1").hide();
                $('#img_gallery1').attr('src', e.target.result);
                $("#img_gallery1").prop('value', 'yes');
                
            }
            reader.readAsDataURL(input.files[0]);
        }
}
function readURL2(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#img_gallery2').attr('src', e.target.result);
                $("#img_gallery2").prop('value', 'yes');
                
            }
            reader.readAsDataURL(input.files[0]);
        }
}
function readURL3(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#img_gallery3').attr('src', e.target.result);
                $("#img_gallery3").prop('value', 'yes');
                
            }
            reader.readAsDataURL(input.files[0]);
        }
}

