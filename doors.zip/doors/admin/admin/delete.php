<?php
include_once("../class/admin_function.php");

$admin = new admin();

session_start();

extract($_GET);




if(isset($_GET['services_id']))
{
	if($admin->deleteContentData("services",$services_id)==1)
	{
		 $_SESSION['smsgbox']="Services successfully deleted.";
	}
	else
	{
		$_SESSION['emsgbox']="Error delete.";
	}
	header("Location:services_list.php");
}



?>