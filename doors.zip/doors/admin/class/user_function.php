<?php
include_once("dbclass.php");
include_once("pagination_func.php");
error_reporting(0);
ob_start();

class user {

    function select_prodect() {
        $db = new dbclass();
        $query = "select * from tb_offer";
        $res = $db->execute($query);
        ?>
        <ul>
            <?php
            while ($r = mysqli_fetch_array($res)) {
                ?>
                <li>
                    <!-- scrtextdiv start -->
                    <div class="scrtext">
                        <a href="view_prodect_details.php?id=<?php echo $r[0];?>"><b style="font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#000033;"><?php echo $r['model']; ?> </b>
                            <p><?php echo substr($r[1],0,200); ?> .... </p>
                        </a>
                    </div>
                    <?php
                    $img = $r[3];
                    $exp = split("#", $img);
                    ?>
                    <div class="serimg"><img src="repository/offer/<?php echo $exp[0]; ?>" border="0"  alt="" width="125"  height="100" oncontextmenu="return false;"/></div>

                </li>
                <?php
            }
            ?>					

        </ul>
        <?php
    }

    //======================================================================================================================
    function max_ofID() {
        $db = new dbclass();
        $query = "SELECT max(id) FROM tb_prodect ";
        $res = $db->execute($query);
        return $res;
    }

    //======================================================================================================================
    function select_new_offer($id) {
        $db = new dbclass();
        $query = "SELECT * FROM tb_prodect where id=$id";
        $res = $db->execute($query);
        //return $res;
        ?>
        
            <?php
            $r = mysqli_fetch_array($res);
            ?>
            
           
<div class="ne"><img src="repository/product/<?php echo $r[4]; ?>" width="235" height="150" border="0"  /></div>
<a href="list_select_new_prodect.php?id=<?php echo $r[0];?>"><div class="ne"><img src="image/Untitled-1.gif" border="0"  /></div></a>
            
        
<?php
    }

    //====================================================================================================================
    function select_news() {
        $db = new dbclass();
        $query = "SELECT * FROM tbl_news_events order by id  DESC limit 0,3";
        $res = $db->execute($query);
        return $res;
    }

    //======================================================================================================================
    function select_prodect_menu() {
        $db = new dbclass();
        $query = "SELECT DISTINCT id,categories FROM tb_categorie order by id  DESC limit 0,6";
        $res = $db->execute($query);
        //return $res;
		?>
		<?php
while($r=mysqli_fetch_array($res))
{
$cat_id=$r[0];
$q="select * from  tb_offer where category='$cat_id'";
$res5 = $db->execute($q);
$rr=mysqli_fetch_array($res5)
?>

<!-- menu div start -->
<div class="menu0"><a href="serch_proces.php?id=<?php echo $r['0'];?>"><?php echo  substr($r['1'],0,20);?></a></div>
<!-- menu div end -->

<?php
}
?>
<div class="menu1"><a href="view_more_prodect.php">More Products</a></div>
<?php
    }

    //======================================================================================================================	
    function select_news_list($id) {
        $db = new dbclass();
        $query = "SELECT * FROM tbl_news_events where id='$id'";
        $res = $db->execute($query);
        return $res;
    }
	//======================================================================================================================
	function select_cat_name($id)
	{ 
	    $db = new dbclass();
        $query = "SELECT * FROM tb_categorie where id=$id ";
        $res = $db->execute($query);
		return $res;
	}

    //======================================================================================================================
    function select__related_news($id) {
        $db = new dbclass();
        $query = "SELECT * FROM tbl_news_events where id!='$id'";
        $res = $db->execute($query);
        return $res;
    }

    //======================================================================================================================	
    function list_photo_all() {
        $my_count = 0;
        $db = new dbclass();
        if ($_GET) {
            $my_count = $_GET['page'];
        }
        $p_limit = 10;
        if ($my_count == '') {
            $my_count = 0;
        } else {
            $my_count = ($_GET['page'] - 1) * $p_limit;
        }
        $query = "select * from tbl_photo_gallery";
        $res = $db->execute($query);
        $cc = mysqli_num_rows($res);
        $sql = "SELECT * FROM  tbl_photo_gallery order by id DESC limit $my_count,$p_limit";
        $c = $db->execute($sql);

        if ($cc == 0) {
            echo '<div style="height:400px;"><br /><br />
							    <h3>No Records found in this Section !</h3></div>';
        } else {
            ?>
            <?php
            while ($r = mysqli_fetch_array($c)) {
                ?>
                <div class="viewall">
                <?php
                $img = $r[2];
                $exp = explode("#", $img);
                ?>
                    <img src="repository/photos/<?php echo $exp[0]; ?>" border="0" alt=""  height="80"  width="80" align="left" class="images" /> 

                    <h2><?php echo $r[1]; ?></h2>

                    <p><small style="float:left;">
                    <?php
                    if ($r[3] == $r[5] && $r[4] == $r[6]) {
                        echo "Created: " . $r[3] . " / " . $r[4];
                    } else {
                        echo "Created: " . $r[3] . " / " . $r[4] . "/" . "Modified: " . $r[5] . " / " . $r[6];
                    }
                    ?>
                        </small> </p>
                    <div class="more"><a href="view_all_photo.php?id=<?php echo $r[0];?>">View more ..</a></div>

                </div>
                            <?php
                        }
                    }
                    ?>
        <div id="paging_base">
                    <?php
                    getPaginationString($_GET['page'], $cc, "10", "1", "list-photo.php", "?page=");
                    ?>
        </div>
        <?php
        //return $res;
    }

    //======================================================================================================================
		function list_photos($id)
		{
		 $db = new dbclass();
		 $q="SELECT * FROM  tbl_photo_gallery  where id=$id";
		 $res = $db->execute($q);
		 return $res;
		}
	//=========================================================================================================================
    function list_viedeo_all() {
        $db = new dbclass();
        $my_count = 0;
        if ($_GET) {
            $my_count = $_GET['page'];
        }
        $p_limit = 10;
        if ($my_count == '') {
            $my_count = 0;
        } else {
            $my_count = ($_GET['page'] - 1) * $p_limit;
        }
        $query = "select * from tbl_video_gallery";
        $res = $db->execute($query);
        $cc = mysqli_num_rows($res);

        $sql = "SELECT * FROM   tbl_video_gallery order by id DESC limit $my_count,$p_limit";
        $c = $db->execute($sql);

        if ($cc == 0) {
            echo '<div style="height:400px;"><br /><br />
			 <h3>No Records found in this Section !</h3></div>';
        } else {

            //$query="SELECT * FROM tbl_video_gallery";
            //$res=$db->execute($query);
            ?>
            <?php
            while ($r = mysqli_fetch_array($c)) {
                ?>
                <div class="viewall">
                <?php
                $string_exp = $r[2];
                $exp = explode(" ", $string_exp);
                $Ex = $exp[3];
                $exp1 = explode("/", $Ex);
                $Ex = $exp1[4];
                $sub = substr($Ex, 0, 11);
                ?>
                    <img style="float:left" src="http://i3.ytimg.com/vi/<?php echo $sub; ?>/default.jpg"  alt="" width="100" height="80" class="images"/>
                    <h2><?php echo $r[1]; ?></h2>

                    <p><small style="float:left;">
                <?php
                if ($r[3] == $r[5] && $r[4] == $r[6]) {
                    echo "Created: " . $r[3] . " / " . $r[4];
                } else {
                    echo "Created: " . $r[3] . " / " . $r[4] . "/" . "Modified: " . $r[5] . " / " . $r[6];
                }
                ?>
                        </small> </p>

                    <div class="more"><a href="view_viedeo.php?id=<?php echo $r[0]; ?>">View more ..</a></div>

                </div>
                    <?php
                }
            }
            ?>
        <div id="paging_base">
        <?php
        getPaginationString($_GET['page'], $cc, "10", "1", "list-video.php", "?page=");
        ?>
        </div>
                    <?php
                }

                //======================================================================================================================
                function view_viedio($id) {
                    $db = new dbclass();
                    $q = "select * from  tbl_video_gallery where id=$id";
                    $res = $db->execute($q);
                    $r = mysqli_fetch_array($res);
                    ?>
        <div id="gallery">
        <?php
        $pattern = "/height=\"[0-9]*\"/";
        $video = preg_replace($pattern, "height='300'", $r[2]);
        $pattern = "/width=\"[0-9]*\"/";
        $video = preg_replace($pattern, "width='550'", $r[2]);
        echo $video;
        ?>
        </div>
            <?php
        }

        //======================================================================================================================	
        function related_viedio($id) {
            $db = new dbclass();
            $q = "select * from  tbl_video_gallery where id!=$id";
            $res = $db->execute($q);
            ?>
        <?php
        while ($r = mysqli_fetch_array($res)) {
            ?>
            <div class="dot"> <a href="view_viedeo.php?id=<?php echo $r[0]; ?>"> <?php echo $r[1]; ?></a></div>

            <?php
			}
        
    }

    //=====================================================================================================================
    function select_list_prodect() {

        $db = new dbclass();
        $q = "select DISTINCT id, categories  from   tb_categorie order by id  DESC";
        $res = $db->execute($q);
        return $res;
    }

    //======================================================================================================================		
	 function list_serch_prodect($id)		
	 {
	   $db = new dbclass();
       $q = "select *  from  tb_offer where category='$id'";
       $res = $db->execute($q);
       return $res;
	 }	
	//======================================================================================================================
	function list_prodect_details($id)
	{
	   $db = new dbclass();
       $q = "select *  from  tb_offer where id=$id";
       $res = $db->execute($q);
       return $res;
	}		
    //======================================================================================================================
	 function list_prodect_right($id)
	 {
	   $db = new dbclass();
       $q = "select *  from  tb_offer where id!=$id  order by id DESC limit 0,3";
       $res = $db->execute($q);
       return $res;
	 }		
    //======================================================================================================================
				function select_new_prodect($id)
				{
				  $db = new dbclass();
       			  $q = "select *  from  tb_prodect where id=$id";
       			  $res = $db->execute($q);
       			  return $res;
				}		
    //======================================================================================================================
	function list_new_prodect_right($id)
		{
	  $db = new dbclass();
      $q = "select *  from  tb_prodect where id!=$id  order by id DESC limit 0,3";
      $res = $db->execute($q);
       return $res;
				}				
    //======================================================================================================================
	   function view_more_prodect()
	   {
	    $db=new dbclass();
	   	$q="select DISTINCT category from  tb_offer  order by id  DESC";
	  	$c=$db->execute($q);
		?>
       <div>
        <?php
		while($r=mysqli_fetch_array($c))
		{
  ?>
  <div><?php $cat= $r['category'];?>
    <?php
	$query="select * from tb_offer where category='$cat' order by category";
	$rr=$db->execute($query);
	while($row=mysqli_fetch_array($rr))
      {

	?>
  <div class="viewall">
     <strong style="font-family: Arial, Helvetica, sans-serif;
color: #873503;
font-size: 12px;
padding-left: 0px;
padding-bottom: 0px;"><?php echo $row['model'];?></strong>
<?php
$img=$row[3];
$ex=explode("#",$img);
?>
 <img src="repository/offer/<?php echo $ex[0];?>" border="0" alt=""  height="80"  width="100" align="left" class="images" /> 

<p> <?php echo substr($row[1],0,110);?> ...</p>
<div class="more"><a href="view_prodect_details.php?id=<?php echo $row[0];?>">View Details</a></div>

</div>
    <?php
	  }
	?>
    </div>
    <?php
	  }
	?>
</div>

        <?php
	   }		
    //=====================================================================================================================	
	function select_product_name($prodect)
	{
	    $db = new dbclass();
        $q = "select *  from   tb_categorie where id =$prodect";
        $res = $db->execute($q);
        return $res;
	}	
    //======================================================================================================================		
    //======================================================================================================================		
    //======================================================================================================================		
				
}?>