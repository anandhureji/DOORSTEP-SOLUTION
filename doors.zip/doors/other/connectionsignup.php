<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "doorstepdb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}




$usr_name = $_POST["usr_name"];
$password = $_POST["password"];
$confirm_password = $_POST["confirm_password"];
$e_mail = $_POST["e_mail"];
$address= $_POST["address"];
$ph_no=$_POST["ph_no"];


$sql = "insert into signup (usr_name,password,confirm_password,e_mail,address,ph_no) values ('$usr_name','$password','$confirm_password','$e_mail','$address','$ph_no');";

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>