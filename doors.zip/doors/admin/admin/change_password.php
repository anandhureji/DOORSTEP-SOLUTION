<?php include_once("include/header.php"); ?>
  <script language="javascript">
function  fun_valid()
{
    
}
</script>

        <div id="page-wrapper" >
            <div id="page-inner">
                
                <div class="row">
                    <div class="col-md-12">
                            <div class="panel-heading">
                              <h2> Change Password </h2>
                            </div> 
                        <h5></h5>   
                    </div>
                    <a href="#" onClick="history.go(-1)" class="btn btn-danger" role="button" style="float:right;margin-right:40px">Go Back</a>
                </div><!-- /. ROW  -->
                
                <hr />
                
                <div class="row">
                    <div class="col-md-12"><!-- Form Elements -->
                        <div class="panel panel-default">
                            

                            
                            <div class="col-lg-6">
                                <div class="panel-body">
                                  
                                        <h3></h3>
                                        
                                        <form role="form"  action="change_password_action.php" enctype="multipart/form-data" method="post" name="form1">
                                            <div class="form-group has-feedback">
                                                <label class="control-label">Enter Old Password   <span style="color:#990000">*</span></label>
                                                <input class="form-control" name="old_password" id="old_password" placeholder="Enter Your Old Password" type="password" aria-describedby="inputStatus" required>
                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>
                                            <div class="form-group has-feedback">
                                                <label class="control-label">Enter New Password   <span style="color:#990000">*</span></label>
                                                <input class="form-control" name="new_password" id="new_password" placeholder="Enter Your New Password" type="password" aria-describedby="inputStatus" required>
                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>
                                            <div class="form-group has-feedback">
                                                <label class="control-label">Confirm Password   <span style="color:#990000">*</span></label>
                                                <input class="form-control" name="new_password2" id="new_password2" placeholder="Confirm Password" type="password" aria-describedby="inputStatus" required>
                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>
                                             <br />
                                            <button type="submit" class="btn btn-success" onClick="return fun_valid()">Change Password</button>
                                            <button type="reset" class="btn btn-primary">Reset </button>
                                           
                                        </form>
                                     
                                    <br/>
                                    <h3></h3>
                                </div>                           
                            </div>

                            <div class="col-lg-6">
                                <h3></h3>
                                <p></p>
                            </div>
                       
                        </div>
                    </div>
                </div>
                
                <!-- /. ROW  -->
                <div class="row">
                    <div class="col-md-12">
                        <h3></h3>
                         <p>
                       
                        </p>
                    </div>
                </div><!-- /. ROW  -->
            
            </div><!-- /. PAGE INNER  -->
        </div><!-- /. PAGE WRAPPER  -->
       
    </div><!-- /. WRAPPER  -->

    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-2.1.3.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.0/jquery.validate.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.0/additional-methods.min.js"></script>
    <script src="assets/js/validation.js"></script>
    
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
