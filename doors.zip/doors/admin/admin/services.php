<?php include_once("include/header.php"); ?>


<?php

$title="";
$desc="";
$sdesc="";

if(isset($_GET["id"]))
{
    $qrydata=$admin->gatOneContentData("services",$_GET["id"]);
    if(mysqli_num_rows($qrydata)>0)
    {
        $rwdata=mysqli_fetch_array($qrydata);
        $title=$rwdata["services_head"];
        $desc=$rwdata["services_description"];
        $sdesc=$rwdata["services_small_description"];
    }
}

?>



        <div id="page-wrapper" >
            <div id="page-inner">
                
                <div class="row">
                    <div class="col-md-12">

                    <?php if(isset($_GET['id'])){ ?>
                        <h2>Edit Services</h2>   
                    <?php }else{ ?>
                        <h2>Add Services</h2>   
                    <?php } ?>

                        <h5></h5>   
                    </div>
                    <a href="#" onclick="history.go(-1)" class="btn btn-danger" role="button" style="float:right;margin-right:40px">Go Back</a>
                </div><!-- /. ROW  -->
                
                <hr />
                
                <div class="row">
                    <div class="col-md-12"><!-- Form Elements -->
                        <div class="panel panel-default">
                            
                            <div class="panel-heading">
                              <strong> Enter Services Details </strong>
                            </div>
                            
                            <div class="col-lg-12">
                                <div class="panel-body">
                                  
                                        <h3></h3>
                                        
                                        <form role="form" id="add_services" action="services_action.php" enctype="multipart/form-data" method="post" name="form1">
                                            
                                            

                                            <div class="form-group has-feedback">
                                                <label class="control-label">Heading   <span style="color:#990000">*</span></label>
                                                <input class="form-control" value="<?php echo $title; ?>" name="title" id="title" placeholder="Enter Heading" type="text" aria-describedby="inputStatus" onchange="showHead(this.value)">
                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>
                                        


                                            <?php if(isset($_GET['id'])){ ?>                                                
                                                <input type="hidden" value="<?php echo $_GET['id']; ?>" name="id" />
                                            <?php } ?>

                                            
                                            <div class="form-group has-feedback">
                                                <label class="control-label">S Description   <span style="color:#990000">*</span></label>
                                                <textarea class="form-control" name="sdescription" id="sdescription" placeholder="Enter S Description"  aria-describedby="inputStatus"><?php echo $sdesc; ?></textarea>
                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>


                                            <div class="form-group has-feedback">
                                                <label class="control-label">Description   <span style="color:#990000">*</span></label>
                                                <textarea class="form-control summernote" name="description" id="description" placeholder="Enter Description"  aria-describedby="inputStatus"><?php echo $desc; ?></textarea>
                                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                <span id="inputStatus" class="sr-only">(success)</span>
                                            </div>
                                            
                                            
                                            
                                             <br />
                                            <button type="submit" class="btn btn-success" onclick="return fun_valid()">Submit </button>
                                            <button type="reset" class="btn btn-primary">Reset </button>
                                           
                                        </form>
                                     
                                    <br/>
                                    <h3></h3>
                                </div>                           
                            </div>

                            <div class="col-lg-6">
                                <h3></h3>
                                <p></p>
                            </div>
                       
                        </div>
                    </div>
                </div>
                
                <!-- /. ROW  -->
                <div class="row">
                    <div class="col-md-12">
                        <h3></h3>
                         <p>
                       
                        </p>
                    </div>
                </div><!-- /. ROW  -->
            
            </div><!-- /. PAGE INNER  -->
        </div><!-- /. PAGE WRAPPER  -->
       
    </div><!-- /. WRAPPER  -->

    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    
    <?php include("include/footer.php");?>