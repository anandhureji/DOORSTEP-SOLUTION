<?php
include_once("../class/admin_function.php");


$admin = new admin();

	

	
$admin= new admin();
	


$page_id="0";
$en_heading="Consultants";
$en_subheading="Consultants";
$en_sm_desc="sm desc";
$en_heading="Consultants";
$en_description="Consultants";
$image="";


 if($admin->addPageContent($page_id,$en_heading,$en_subheading,$en_sm_desc,$en_description,$image,1)==1)
 {
	  echo "Content successfully Updated.";
 }
 else
 {
	  echo "Error Update.";

 }


?>
