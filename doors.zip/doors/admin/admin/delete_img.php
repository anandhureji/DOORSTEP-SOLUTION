<?php

include_once("../class/admin_function.php");
$admin= new admin();
extract($_GET);
if(isset($_GET['img_id']))
{
	$admin->deleteImage($img_id,$img);
	$_SESSION['smsgbox']="Image removed !";
	header("Location:gallery.php");
}

?>