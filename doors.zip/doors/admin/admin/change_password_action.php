<?php

include_once("../class/admin_function.php");

session_start();

$user_id=$_SESSION['user_id'];

$old_password=md5($_POST['old_password']);

$new_password=($_POST['new_password']);

$new_password2=($_POST['new_password2']);

$admin=new admin();


if($new_password==$new_password2)
{
    if($admin->getPassword($user_id)==$old_password)
    {
        if($new_password!="")
        {
            $admin->setPasswprd($user_id, md5($new_password));
            $_SESSION['smsgbox']="Password successfully changed.";
        }
        else
        {
            $_SESSION['emsgbox']="Enter a new password";  
        }
    }
    else
    {
        $_SESSION['emsgbox']="Wrong old password.";
    }
     
}
else
{
     $_SESSION['emsgbox']="Password Not Match.";
}

header("Location:change_password.php");

?>