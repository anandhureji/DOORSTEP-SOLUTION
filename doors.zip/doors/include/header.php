	
	<?php 
		session_start();
		include "admin/class/public_function.php" ;
		$pub = new pub();
	?>



	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>DoorStep Solutions</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">							
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/main.css">
		</head>
		<body>	
			  <header id="header" id="home">
		  		<div class="header-top">
		  			<div class="container">
				  		<div class="row">
				  			<div class="col-lg-6 col-sm-6 col-4 header-top-left no-padding">
				  				<ul>
									<li><a href="https://www.facebook.com"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
									<li><a href="#"><i class="fa fa-behance"></i></a></li>
				  				</ul>
				  			</div>
				  			<div class="col-lg-6 col-sm-6 col-8 header-top-right no-padding">
				  				<a href="tel:+91 9544233382">+91 9544233382</a>
				  				<a href="mailto:support@doorstepssolutions.com">support@doorstepssolutions.com</a>				
				  			</div>
				  		</div>			  					
		  			</div>
				</div>
			    <div class="container main-menu">
			    	<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo">
				        <a href="#"><img src="img/bitmap.png" alt="" title="" /></a>
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li class="menu-active"><a href="index.php">Home</a></li>
							<li><a href="about.php">About</a></li>
								
				          <li><a href="service.php">Service</a></li>
				          <li><a href="feedback.php">Feedback</a></li>
				          <li class="menu-has-children"><a href="">Blog</a>
				            <ul>
				              <li><a href="blog.php">Blog Home</a></li>
				              <li><a href="blog.php">Blog Single</a></li>
				            </ul>
				          </li>						          
			              <li><a href="elements.php">Elements</a></li>				          
				          <li><a href="contact.php">Contact</a></li>
				        </ul>
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header><!-- #header -->

		

<style>
#snackbar_s,#snackbar_e {
    visibility: hidden;
    min-width: 250px;
    margin-left: -125px;
    background-color: green;
    color: #fff;
    text-align: center;
    border-radius: 2px;
    padding: 16px;
    position: fixed;
    z-index: 1000;
     right: 2%;
    top: 30px;
    font-size: 17px;
}
#snackbar_e{
    background-color: #f17373!important;
}
#snackbar_s.show,#snackbar_e.show{
    visibility: visible;
    -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
    animation: fadein 0.5s, fadeout 0.5s 2.5s;
}
</style>  
<?php if(isset($_SESSION['smsgbox'])){ ?>
	<div id="snackbar_s"><?php echo $_SESSION['smsgbox']; ?></div>
	<script>
		var x = document.getElementById("snackbar_s")
		x.className = "show";
		setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
	</script>
<?php unset($_SESSION['smsgbox']); } ?>


<?php if(isset($_SESSION['emsgbox'])){ ?>
	<div id="snackbar_e"><?php echo $_SESSION['emsgbox']; ?></div>
	<script>
		 var x = document.getElementById("snackbar_e")
		 x.className = "show";
		 setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
	</script>
<?php unset($_SESSION['emsgbox']); } ?>

     