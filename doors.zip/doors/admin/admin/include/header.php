<?php

	include_once("user_validate.php");

	include_once("../class/admin_function.php");
	$admin = new admin();
	
	$admin_id=$_SESSION['user_id'];

    $page_name=basename($_SERVER['PHP_SELF']);

?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   
   <link href="assets/css/news_letter.css" rel="stylesheet" />
   
   <link rel="stylesheet" href="assets/editor/summernote.css" />
   
   
   
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a style="font-size: 18px;" class="navbar-brand" href="home.php">Admin</a> 
            </div>
  <div style="color: white;padding: 15px 50px 5px 50px;float: right;font-size: 16px;"> 

 <a href="logout.php" class="btn btn-primary square-btn-adjust" style="background-color:#406d77;">Logout</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
					</li>
				
					
                    
                    <li>
                        <a href="home.php"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
                    

        
 

                    <li>
                        <a  href="gallery.php"><i class="fa fa-image fa-3x"></i>Image Gallery</a>
                    </li>



                     <li>
                        <a  href="list_content.php"><i class="fa fa-book fa-3x"></i> Services<span class="fa arrow"></span></a>
                        
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="services.php">Add Services &nbsp;</a>
                            </li>
                             <li>
                                <a href="services_list.php">Manage Services &nbsp;</a>
                            </li>
                            
                        </ul>
                    </li>

                  

                    
                    <li>
                    <a  href="#"><i class="fa fa-cog fa-3x"></i> Settings<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                           <li>
                                <a href="settings.php">Settings</a>
                            </li>
                           
                            <li>
                                <a href="change_password.php">Change Password</a>
                            </li>
                            
                        </ul>
                    </li>
                    
					
                    
                   
                
                </ul>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->
        
        
<script>

function confirmDelete() { 

 return confirm("Press OK to Delete. ");   

} 
</script>




<style>
#snackbar_s,#snackbar_e {
    visibility: hidden;
    min-width: 250px;
    margin-left: -125px;
    background-color: green;
    color: #fff;
    text-align: center;
    border-radius: 2px;
    padding: 16px;
    position: fixed;
    z-index: 1000;
     right: 2%;
    top: 30px;
    font-size: 17px;
}
#snackbar_e{
    background-color: #f17373!important;
}
#snackbar_s.show,#snackbar_e.show{
    visibility: visible;
    -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
    animation: fadein 0.5s, fadeout 0.5s 2.5s;
}
</style>  
<?php if(isset($_SESSION['smsgbox'])){ ?>
	<div id="snackbar_s"><?php echo $_SESSION['smsgbox']; ?></div>
	<script>
		var x = document.getElementById("snackbar_s")
		x.className = "show";
		setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
	</script>
<?php unset($_SESSION['smsgbox']); } ?>


<?php if(isset($_SESSION['emsgbox'])){ ?>
	<div id="snackbar_e"><?php echo $_SESSION['emsgbox']; ?></div>
	<script>
		 var x = document.getElementById("snackbar_e")
		 x.className = "show";
		 setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
	</script>
<?php unset($_SESSION['emsgbox']); } ?>

     









