<!DOCTYPE html>
<html>
<head>
<style>
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
</style>
</head>
<body>

<h2>Request Repair</h2>
<p>Please Submit The Corresponding Form Details.</p>

<div class="container">
  <form  method="post" action="connection.php"  >
  <div class="row">
    <div class="col-25">
      <label for="ename">Email Address :</label>
    </div>
    <div class="col-75">
      <input type="text" id="ename" name="emailid" placeholder="Your mail id">
    </div>
  </div>
  <H3>Enter Your Product INFO </H3>
  <div class="row">
    <div class="col-25">
      <label for="mno">System Info :</label>
    </div>
    <div class="col-75">
      <input type="text" id="mno" name="systeminfo" placeholder="System No">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="sno">Specification :</label>
    </div>
    <div class="col-75">
      <input type="text" id="sno" name="spec" placeholder="Specification">
        
    </div>
  </div>
  <h3>CONTACT INFORMATION</H3>
  <div class="container">
  <form action="/action_page.php">
  <div class="row">
    <div class="col-25">
      <label for="fname">Username :</label>
    </div>
    <div class="col-75">
      <input type="text" id="fname" name="usrname" placeholder="Enter Your Username:">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="subject">Address:</label>
    </div>
    <div class="col-75">
      <textarea id="subject" name="address" placeholder="Enter Your Address..." style="height:100px"></textarea>
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="pcode">Pin Code :</label>
    </div>
    <div class="col-75">
      <input type="text" id="pcode" name="pincode" placeholder="Your pin code..">
    </div>
    </div>
  <div class="row">
    <div class="col-25">
      <label for="country">Country</label>
    </div>
    <div class="col-75">
      <select id="country" name="country">
        <option value="australia">Australia</option>
        <option value="canada">Canada</option>
        <option value="usa">USA</option>
        <option value="india">INDIA</OPTION>
      </select>
      </div>
      <div class="row">
    <div class="col-25">
      <label for="Phnone No:">Phone No :</label>
    </div>
    <div class="col-75">
      <input type="text" id="Pno" name="phno" placeholder="Your Phone No :">
    </div>
  </div>
  <div class="row">
    <div class="col-25">
      <label for="subject">Message :</label>
    </div>
    <div class="col-75">
      <textarea id="subject" name="message" placeholder="Write something.." style="height:200px"></textarea>
    </div>
  </div>
  <div class="row">
    <input type="submit" style="margin-left: 20px" value="Submit">
    <input type="submit" value="Clear">
      
    </div>
      
    </div>
  
  </form>
</div>
  </div>
  </form>
</div>

</body>
</html>
