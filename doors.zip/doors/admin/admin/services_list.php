<?php include_once("include/header.php");
 ?>
         
        <div id="page-wrapper" >
            <div id="page-inner">
                
                <div class="row">
                    <div class="col-md-12">
                       <!-- <h2>Add Category</h2>   -->
<!--                        <h5>Please enter the ..</h5>   -->
                    </div>
                </div><!-- /. ROW  -->
                
                <hr />
                
                <div class="row">
                    <div class="col-md-12"><!-- Form Elements -->
                        <div class="panel panel-default">
                            
                            <div class="panel-heading">
                                <h2>Manage Services</h2> 
                            </div>
                            
                            <div class="col-lg-12">
                                <div class="panel-body">
                                  
                                      
                                                                
                                       
<?php

	//paging
	$limit = 10;  
	if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };  
	$start_from = ($page-1) * $limit;  
	//paging end
	
	$i=$start_from +1;
	
	$data=$admin->gatContentData("services",$start_from, $limit);
	if(mysqli_num_rows($data)!=0){
?>                                      
                
 <table class="table table-striped">
      <thead>
          <tr>
            <th>No:</th>
            
            
            <th>Services Heading</th>
            
            <th>Date</th>
            <th>Time</th>
            
            <th>Edit</th> 
            <th>Delete</th>
         </tr>
	</thead>
    
	<tbody>
	<?php 


    while($rw=mysqli_fetch_assoc($data))
    {
    ?>
    
              <tr>
              	<th><?php echo $i++; ?></th>
                <td><?php echo $rw['services_head']; ?></td>
                <td><?php echo $rw['services_date']; ?></td>
                <td><?php echo $rw['services_time']; ?></td>
                <td> 
                
                
                 <a href="services.php?id=<?php echo $rw['services_id']; ?>"   class="btn btn-primary btn-big" ><i class="fa fa-edit" aria-hidden="true"></i></a>
                
                
                </td>
                
               <td> <a href="delete.php?services_id=<?php echo $rw['services_id']; ?>" onclick="return confirmDelete();" class="btn btn-danger btn-big" ><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                
               </tr>

              
              
    <?php } ?>
    
    </tbody>

</table> 
                   
        


<?php
$rows= $admin->getTableCnt('tbl_services');
$total=ceil($rows/$limit);
?>
<nav class="news-letter-nav" aria-label="...">
	<ul class="pagination">
		<?php if($page>1){?><li class="page-item"><?php echo "<a class='page-link' href='?page=".($page-1)."' tabindex='-1' aria-label='Previous'>"; ?>
		<span aria-hidden="true">&laquo;</span><span class="sr-only">Previous</span></a></li>
		<?php } ?>	

		<?php for($j=1;$j<=$total;$j++){if($j==$page) { ?>
			<li class="page-item active"><a class="page-link" href="#"><?php echo $j;?><span class="sr-only">(current)</span></a></li>
		<?php }else{ echo "<li class='page-item'><a class='page-link' href='?page=".$j."'>".$j."</a></li>"; ?> <?php }}?>
			
		<?php if($page!=$total){?>
				<li class="page-item">
					<a class="page-link" href="<?php echo " ?page=".($page+1); ?>" aria-label="Next">
						<span aria-hidden="true">&raquo;</span>
						<span class="sr-only">Next</span>
					</a>
				</li>
		<?php } ?>
	</ul>
</nav>                                  
             
 
<?php

}
else
{
	echo"<p style='clear:both;width:100%;'><h4 style='text-align: center; color: #fff; background-color: rgba(189, 134, 130, 0.54); padding-bottom: 10px;'>No results</h4></p>";
}
?>
                            			
                                       
                                </div>                           
                            </div>

                            
                       
                        </div>
                    </div>
                </div>
                
               
            
            </div><!-- /. PAGE INNER  -->
        </div><!-- /. PAGE WRAPPER  -->
       
    </div><!-- /. WRAPPER  -->

    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->





 <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    


    

    
   
</body>
</html>
