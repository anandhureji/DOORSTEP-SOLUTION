<?php
include_once("dbclass.php");

include_once("pagination_func.php");

//error_reporting(0);
ob_start();

class admin
{


	function login($uname,$pwd) //check login
	{
		$db= new dbclass();
		$query="select * from tbl_users where user_email='$uname' and user_password='$pwd' and user_status='active'";
		$res=$db->execute($query);

		return $res;
	}

	function gatContent($start_from="", $limit="")
	{
		$db= new dbclass();
		if($limit=="" && $start_from=="")
			$query="select * from tbl_content";
		else
			$query="select * from tbl_content order by content_id asc LIMIT $start_from, $limit";
		$res=$db->execute($query);
		return $res;	
	}
	
	

	
	//new update
	function gatContentData($about,$start_from="", $limit="")
	{
		$db= new dbclass();
		if($limit=="" && $start_from=="")
			$query="select * from tbl_".$about." order by ".$about."_id desc";
		else
			$query="select * from tbl_".$about." order by ".$about."_id desc LIMIT $start_from, $limit";
		$res=$db->execute($query);
		return $res;	
	}
	
	function gatOneContentData($about,$id)
	{
		$db= new dbclass();

		$query="select * from tbl_".$about." WHERE ".$about."_id='$id'";
		
		$res=$db->execute($query);
		return $res;	
	}
	
	function addContentData($about,$title,$desc,$sdesc="")
	{
		$db= new dbclass();
		if($sdesc=="")
		{
			$query="INSERT INTO `tbl_".$about."` (`".$about."_head`, `".$about."_description`, `".$about."_date`, `".$about."_time`, `user_id`) VALUES ('$title', '$desc', CURDATE(), CURTIME(), 1);";
		}
		else
		{
			$query="INSERT INTO `tbl_".$about."` (`".$about."_head`, `".$about."_description`,`".$about."_small_description`, `".$about."_date`, `".$about."_time`, `user_id`) VALUES ('$title', '$desc','$sdesc', CURDATE(), CURTIME(), 1);";
		}
		$res=$db->execute($query);
		return $res;	
	}
	
	function updateContentData($about,$title, $desc,$sdesc="",$id)
	{
		$db= new dbclass();
		if($sdesc=="")
		{
			$query="UPDATE `tbl_".$about."` SET `".$about."_head`='$title', `".$about."_description`='$desc' WHERE  `".$about."_id`= $id";
		}
		else
		{
			$query="UPDATE `tbl_".$about."` SET `".$about."_head`='$title', `".$about."_description`='$desc', `".$about."_small_description`='$sdesc' WHERE  `".$about."_id`= $id";
		}
		$res=$db->execute($query);
		return $res;	
	}

	function deleteContentData($about,$id)
	{
		$db= new dbclass();
		$query="DELETE FROM `tbl_".$about."` WHERE  `".$about."_id`='$id';";
		$res=$db->execute($query);
		return $res;	
	}








	function gatOneContent($id)
	{
		$db= new dbclass();
		$query="select * from tbl_content where content_id='$id'";
		$res=$db->execute($query);
		return $res;	
	}

	
	function getTableCnt($tbl_name)
	{
		$db= new dbclass();
		$query="SELECT * FROM $tbl_name";
		$res=$db->execute($query);
		$res=mysqli_num_rows($res);
		return $res;	
	}



	
	function getSelectList($id,$name,$table_name,$where="",$selectvalue="")
	{
		$db= new dbclass();
		if($where !=""){$where=" where  ".$where;}
		$query="select $id as id,$name as name from  $table_name $where";
		$res=$db->execute($query);
		$data="";
		while( $row=mysqli_fetch_assoc($res))
		{
			$sel="";if($selectvalue==$row['id']){$sel=" selected='selected' ";}
			$data.="<option value='".$row['id']."' ".$sel.">".$row['name']."</option>";
		}
		return $data;	
	}
	

	function maxValueTable($id,$table)
	{
		$db= new dbclass();
		$query="select max($id) as id from $table";
		$res=$db->execute($query);
		$data="0";
		if($row=mysqli_fetch_assoc($res))
		{
			$data=$row['id'];
		}
		return $data;	
	}

	

	
	function addImage($img,$title)
	{
		$db= new dbclass();
		$query="INSERT INTO `tbl_gallery_image` (`image`,`title`, `date`, `time`) VALUES ('$img','$title', now(), now());";
		$res=$db->execute($query);
		return $res;	
	}
	
	function deleteImage($img_id,$img_name)
	{
		$db= new dbclass();		

		unlink("../../upload/gallery/".$img_name);	
		unlink("../../upload/gallery/thumb/".$img_name);	

		$query="DELETE FROM `tbl_gallery_image` WHERE `image_id`='$img_id'";
		$res=$db->execute($query);	
				
		return $res;	
	}
	


	


	function gatImageList()
	{
		$db= new dbclass();
		$query="select * from tbl_gallery_image order by image_id desc ";
		$res=$db->execute($query);
		return $res;	
	}

	function gatGalList()
	{
		$db= new dbclass();
		$query="select * from tbl_gal_image order by image_id desc ";
		$res=$db->execute($query);
		return $res;	
	}


	function setSettings($name,$value)
	{
		$db= new dbclass();
		$chkres=$db->execute("select * from tbl_settings where settings_name='$name'");

		if(mysqli_num_rows($chkres)==0)
		{
			$query="INSERT INTO `tbl_settings` (`settings_name`, `settings_value`) VALUES ('$name', '$value')";
		}
		else
		{
			$query="UPDATE `tbl_settings` SET `settings_value`='$value' WHERE  `settings_name`='$name'";
		}
		$res=$db->execute($query);
		return $res;
	}
	
	function getSettings($name)
	{
		$db= new dbclass();
		$query="SELECT settings_value from tbl_settings where  `settings_name`='$name'";
		$res=$db->execute($query);

		if(mysqli_num_rows($res)!=0)
		{
			$rw=mysqli_fetch_assoc($res);
			return $rw["settings_value"];	
		}
		else
		{
			return "";
		}
	}



	function getPassword($user_id)
	{
		$db= new dbclass();
		$query="SELECT user_password from tbl_users where  `user_id`='$user_id'";
		$res=$db->execute($query);

		if(mysqli_num_rows($res)!=0)
		{
			$rw=mysqli_fetch_assoc($res);
			return $rw["user_password"];	
		}
		else
		{
			return "wwwwwwwww";
		}
	}

	function setPasswprd($id,$password)
	{
		$db= new dbclass();
		$query="UPDATE `tbl_users` SET `user_password`='$password' WHERE  `user_id`='$id'";
		$res=$db->execute($query);
		return $res;
	}

	


	function RunSql($sql)
	{
		$db= new dbclass();
		$query=$sql;
		$res=$db->execute($query);
		return $res;
	}


}
?>